﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LanceCerto.WebApp.Migrations
{
    public partial class AjustarPrecisaoDecimais : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
